<?php
if (is_object($term) && $term) {
    $primary_color = get_term_meta($term->term_id, $this->_cat_primary_color, true);
    if (!isset($primary_color)) {
        $primary_color = add_term_meta($term->term_id, $this->_cat_primary_color, '', true);
    }

    $atc_text_color = get_term_meta($term->term_id, $this->_cat_add_to_cart_text_color, true);
    if (!isset($atc_text_color)) {
        $atc_text_color = add_term_meta($term->term_id, $this->_cat_add_to_cart_text_color, '', true);
    }

    $atc_bg_color = get_term_meta($term->term_id, $this->_cat_add_to_cart_bg_color, true);
    if (!isset($atc_bg_color)) {
        $atc_bg_color = add_term_meta($term->term_id, $this->_cat_add_to_cart_bg_color, '', true);
    }

    ?>
    <tr class="form-field nasa-term-root nasa-term-primary_color hidden-tag ns-advance-field">
        <th scope="row" valign="top">
            <label for="<?php echo $this->_cat_primary_color; ?>"><?php _e('Primary Color', 'nasa-core'); ?></label>
        </th>
        <td>
            <div class="nasa_p_color">
                <input type="text" class="widefat nasa-color-field" id="<?php echo $this->_cat_primary_color; ?>" name="<?php echo $this->_cat_primary_color; ?>" value="<?php echo isset($primary_color) ? esc_attr($primary_color) : ''; ?>" />
            </div>
       </td>
    </tr>

    <tr class="form-field nasa-term-root nasa-term-add_to_cart_text_color hidden-tag ns-advance-field">
        <th scope="row" valign="top">
            <label for="<?php echo $this->_cat_add_to_cart_text_color; ?>"><?php _e('Add To Cart Text Color', 'nasa-core'); ?></label>
        </th>
        <td>
            <div class="nasa_p_color">
                <input type="text" class="widefat nasa-color-field" id="<?php echo $this->_cat_add_to_cart_text_color; ?>" name="<?php echo $this->_cat_add_to_cart_text_color; ?>" value="<?php echo isset($atc_text_color) ? esc_attr($atc_text_color) : ''; ?>" />
            </div>
       </td>
    </tr>

    <tr class="form-field nasa-term-root nasa-term-add_to_cart_bg_color hidden-tag ns-advance-field">
        <th scope="row" valign="top">
            <label for="<?php echo $this->_cat_add_to_cart_bg_color; ?>"><?php _e('Add To Cart Background Color', 'nasa-core'); ?></label>
        </th>
        <td>
            <div class="nasa_p_color">
                <input type="text" class="widefat nasa-color-field" id="<?php echo $this->_cat_add_to_cart_bg_color; ?>" name="<?php echo $this->_cat_add_to_cart_bg_color; ?>" value="<?php echo isset($atc_bg_color) ? esc_attr($atc_bg_color) : ''; ?>" />
            </div>
       </td>
    </tr>
    
<?php } else { ?>
    <div class="form-field nasa-term-root nasa-term-primary_color hidden-tag ns-advance-field">
        <label for="<?php echo $this->_cat_primary_color; ?>"><?php _e('Primary Color', 'nasa-core'); ?></label>
        <div class="nasa_p_color">
            <input type="text" class="widefat nasa-color-field" id="<?php echo $this->_cat_primary_color; ?>" name="<?php echo $this->_cat_primary_color; ?>" value="" />
        </div>
    </div>
    <div class="form-field nasa-term-root nasa-term-add_to_cart_text_color hidden-tag ns-advance-field">
        <label for="<?php echo $this->_cat_add_to_cart_text_color; ?>"><?php _e('Add To Cart Text Color', 'nasa-core'); ?></label>
        <div class="nasa_p_color">
            <input type="text" class="widefat nasa-color-field" id="<?php echo $this->_cat_add_to_cart_text_color; ?>" name="<?php echo $this->_cat_add_to_cart_text_color; ?>" value="" />
        </div>
    </div>

    <div class="form-field nasa-term-root nasa-term-add_to_cart_bg_color hidden-tag ns-advance-field">
        <label for="<?php echo $this->_cat_add_to_cart_bg_color; ?>"><?php _e('Add To Cart Background Color', 'nasa-core'); ?></label>
        <div class="nasa_p_color">
            <input type="text" class="widefat nasa-color-field" id="<?php echo $this->_cat_add_to_cart_bg_color; ?>" name="<?php echo $this->_cat_add_to_cart_bg_color; ?>" value="" />
        </div>
    </div>
<?php
}
